#Seabreeze Ceramics

This is the website repository for [seabreezeceramic.co.uk]. A business making handmade animal pawprint ceramic tiles and other unique gifts.